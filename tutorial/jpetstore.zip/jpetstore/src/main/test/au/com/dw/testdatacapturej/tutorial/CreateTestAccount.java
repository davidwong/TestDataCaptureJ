package au.com.dw.testdatacapturej.tutorial;

public class CreateTestAccount {
	
	public org.springframework.samples.jpetstore.domain.Account createParam1Account_org_springframework_samples_jpetstore_domain_Order_initOrder() {

	org.springframework.samples.jpetstore.domain.Account account0 = new org.springframework.samples.jpetstore.domain.Account();
	account0.setUsername("j2ee");
	account0.setPassword(null);
	account0.setEmail("yourname@yourdomain.com");
	account0.setFirstName("ABC");
	account0.setLastName("XYX");
	account0.setStatus("OK");
	account0.setAddress1("901 San Antonio Road");
	account0.setAddress2("MS UCUP02-206");
	account0.setCity("Palo Alto");
	account0.setState("CA");
	account0.setZip("94303");
	account0.setCountry("USA");
	account0.setPhone("555-555-5555");
	account0.setFavouriteCategoryId("DOGS");
	account0.setLanguagePreference("english");
	account0.setListOption(true);
	account0.setBannerOption(true);
	account0.setBannerName("<image src=\"../images/banner_dogs.gif\">");

	return account0;
	}

}
