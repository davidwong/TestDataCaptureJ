package au.com.dw.testdatacapturej.tutorial;

public class CreateTestCart_Empty {
	
	// copy and paste generated method here
	
}
