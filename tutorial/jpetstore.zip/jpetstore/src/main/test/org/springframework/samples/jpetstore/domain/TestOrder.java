package org.springframework.samples.jpetstore.domain;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestOrder {

	@Test
	public void testInitOrder() {
		fail("Not yet implemented");
	}

}
