package org.springframework.samples.jpetstore.domain;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MockCreator {

	public Account createAccount()
	{
		//org.springframework.samples.jpetstore.domain.Account account = new org.springframework.samples.jpetstore.domain.Account();
		org.springframework.samples.jpetstore.domain.Account account0 = new org.springframework.samples.jpetstore.domain.Account();
		account0.setUsername("j2ee");
		account0.setPassword(null);
		account0.setEmail("yourname@yourdomain.com");
		account0.setFirstName("ABC");
		account0.setLastName("XYX");
		account0.setStatus("OK");
		account0.setAddress1("901 San Antonio Road");
		account0.setAddress2("MS UCUP02-206");
		account0.setCity("Palo Alto");
		account0.setState("CA");
		account0.setZip("94303");
		account0.setCountry("USA");
		account0.setPhone("555-555-5555");
		account0.setFavouriteCategoryId("DOGS");
		account0.setLanguagePreference("english");
		account0.setListOption(true);
		account0.setBannerOption(true);
		account0.setBannerName("<image src=\"../images/banner_dogs.gif\">");
		
		return account0;
		
	}
	
	public Cart createCart()
	{
		org.springframework.samples.jpetstore.domain.Cart cart0 = new org.springframework.samples.jpetstore.domain.Cart();

		Map collections$SynchronizedMap0 = Collections.synchronizedMap(new HashMap());

		org.springframework.samples.jpetstore.domain.CartItem cartItem1 = new org.springframework.samples.jpetstore.domain.CartItem();

		org.springframework.samples.jpetstore.domain.Item item2 = new org.springframework.samples.jpetstore.domain.Item();
		item2.setItemId("EST-6");
		item2.setProductId("K9-BD-01");
		item2.setListPrice(18.5d);
		item2.setUnitCost(12.0d);
		item2.setSupplierId(1);
		item2.setStatus("P");
		item2.setAttribute1("Male Adult");
		item2.setAttribute2(null);
		item2.setAttribute3(null);
		item2.setAttribute4(null);
		item2.setAttribute5(null);

		org.springframework.samples.jpetstore.domain.Product product3 = new org.springframework.samples.jpetstore.domain.Product();
		product3.setProductId("K9-BD-01");
		product3.setCategoryId("DOGS");
		product3.setName("Bulldog");
		product3.setDescription("<image src=\"../images/dog2.gif\">Friendly dog from England");
		item2.setProduct(product3);
		item2.setQuantity(10000);
		cartItem1.setItem(item2);
		cartItem1.setQuantity(2);
		cartItem1.setInStock(true);

		collections$SynchronizedMap0.put("EST-6", cartItem1);

		org.springframework.samples.jpetstore.domain.CartItem cartItem4 = new org.springframework.samples.jpetstore.domain.CartItem();

		org.springframework.samples.jpetstore.domain.Item item5 = new org.springframework.samples.jpetstore.domain.Item();
		item5.setItemId("EST-18");
		item5.setProductId("AV-CB-01");
		item5.setListPrice(193.5d);
		item5.setUnitCost(92.0d);
		item5.setSupplierId(1);
		item5.setStatus("P");
		item5.setAttribute1("Adult Male");
		item5.setAttribute2(null);
		item5.setAttribute3(null);
		item5.setAttribute4(null);
		item5.setAttribute5(null);

		org.springframework.samples.jpetstore.domain.Product product6 = new org.springframework.samples.jpetstore.domain.Product();
		product6.setProductId("AV-CB-01");
		product6.setCategoryId("BIRDS");
		product6.setName("Amazon Parrot");
		product6.setDescription("<image src=\"../images/bird4.gif\">Great companion for up to 75 years");
		item5.setProduct(product6);
		item5.setQuantity(-4990000);
		cartItem4.setItem(item5);
		cartItem4.setQuantity(1);
		cartItem4.setInStock(false);

		collections$SynchronizedMap0.put("EST-18", cartItem4);

		org.springframework.samples.jpetstore.domain.CartItem cartItem7 = new org.springframework.samples.jpetstore.domain.CartItem();

		org.springframework.samples.jpetstore.domain.Item item8 = new org.springframework.samples.jpetstore.domain.Item();
		item8.setItemId("EST-17");
		item8.setProductId("FL-DLH-02");
		item8.setListPrice(93.5d);
		item8.setUnitCost(12.0d);
		item8.setSupplierId(1);
		item8.setStatus("P");
		item8.setAttribute1("Adult Male");
		item8.setAttribute2(null);
		item8.setAttribute3(null);
		item8.setAttribute4(null);
		item8.setAttribute5(null);

		org.springframework.samples.jpetstore.domain.Product product9 = new org.springframework.samples.jpetstore.domain.Product();
		product9.setProductId("FL-DLH-02");
		product9.setCategoryId("CATS");
		product9.setName("Persian");
		product9.setDescription("<image src=\"../images/cat1.gif\">Friendly house cat, doubles as a princess");
		item8.setProduct(product9);
		item8.setQuantity(10000);
		cartItem7.setItem(item8);
		cartItem7.setQuantity(1);
		cartItem7.setInStock(true);

		collections$SynchronizedMap0.put("EST-17", cartItem7);

		cart0.setItemMap(collections$SynchronizedMap0);

		org.springframework.beans.support.PagedListHolder pagedListHolder10 = new org.springframework.beans.support.PagedListHolder();

		java.util.ArrayList arrayList0 = new java.util.ArrayList();

		org.springframework.samples.jpetstore.domain.CartItem cartItem11 = new org.springframework.samples.jpetstore.domain.CartItem();

		org.springframework.samples.jpetstore.domain.Item item12 = new org.springframework.samples.jpetstore.domain.Item();
		item12.setItemId("EST-6");
		item12.setProductId("K9-BD-01");
		item12.setListPrice(18.5d);
		item12.setUnitCost(12.0d);
		item12.setSupplierId(1);
		item12.setStatus("P");
		item12.setAttribute1("Male Adult");
		item12.setAttribute2(null);
		item12.setAttribute3(null);
		item12.setAttribute4(null);
		item12.setAttribute5(null);

		org.springframework.samples.jpetstore.domain.Product product13 = new org.springframework.samples.jpetstore.domain.Product();
		product13.setProductId("K9-BD-01");
		product13.setCategoryId("DOGS");
		product13.setName("Bulldog");
		product13.setDescription("<image src=\"../images/dog2.gif\">Friendly dog from England");
		item12.setProduct(product13);
		item12.setQuantity(10000);
		cartItem11.setItem(item12);
		cartItem11.setQuantity(2);
		cartItem11.setInStock(true);
		arrayList0.add(cartItem11);

		org.springframework.samples.jpetstore.domain.CartItem cartItem14 = new org.springframework.samples.jpetstore.domain.CartItem();

		org.springframework.samples.jpetstore.domain.Item item15 = new org.springframework.samples.jpetstore.domain.Item();
		item15.setItemId("EST-17");
		item15.setProductId("FL-DLH-02");
		item15.setListPrice(93.5d);
		item15.setUnitCost(12.0d);
		item15.setSupplierId(1);
		item15.setStatus("P");
		item15.setAttribute1("Adult Male");
		item15.setAttribute2(null);
		item15.setAttribute3(null);
		item15.setAttribute4(null);
		item15.setAttribute5(null);

		org.springframework.samples.jpetstore.domain.Product product16 = new org.springframework.samples.jpetstore.domain.Product();
		product16.setProductId("FL-DLH-02");
		product16.setCategoryId("CATS");
		product16.setName("Persian");
		product16.setDescription("<image src=\"../images/cat1.gif\">Friendly house cat, doubles as a princess");
		item15.setProduct(product16);
		item15.setQuantity(10000);
		cartItem14.setItem(item15);
		cartItem14.setQuantity(1);
		cartItem14.setInStock(true);
		arrayList0.add(cartItem14);

		org.springframework.samples.jpetstore.domain.CartItem cartItem17 = new org.springframework.samples.jpetstore.domain.CartItem();

		org.springframework.samples.jpetstore.domain.Item item18 = new org.springframework.samples.jpetstore.domain.Item();
		item18.setItemId("EST-18");
		item18.setProductId("AV-CB-01");
		item18.setListPrice(193.5d);
		item18.setUnitCost(92.0d);
		item18.setSupplierId(1);
		item18.setStatus("P");
		item18.setAttribute1("Adult Male");
		item18.setAttribute2(null);
		item18.setAttribute3(null);
		item18.setAttribute4(null);
		item18.setAttribute5(null);

		org.springframework.samples.jpetstore.domain.Product product19 = new org.springframework.samples.jpetstore.domain.Product();
		product19.setProductId("AV-CB-01");
		product19.setCategoryId("BIRDS");
		product19.setName("Amazon Parrot");
		product19.setDescription("<image src=\"../images/bird4.gif\">Great companion for up to 75 years");
		item18.setProduct(product19);
		item18.setQuantity(-4990000);
		cartItem17.setItem(item18);
		cartItem17.setQuantity(1);
		cartItem17.setInStock(false);
		arrayList0.add(cartItem17);

		pagedListHolder10.setSource(arrayList0);

		java.util.Date date20 = new java.util.Date();
		date20.setFastTime(1276785658015L);
		date20.setCdate(null);
		pagedListHolder10.setRefreshDate(date20);

		org.springframework.beans.support.MutableSortDefinition mutableSortDefinition21 = new org.springframework.beans.support.MutableSortDefinition();
		mutableSortDefinition21.setProperty("");
		mutableSortDefinition21.setIgnoreCase(true);
		mutableSortDefinition21.setAscending(true);
		mutableSortDefinition21.setToggleAscendingOnProperty(true);
		pagedListHolder10.setSort(mutableSortDefinition21);
		pagedListHolder10.setSortUsed(null);
		pagedListHolder10.setPageSize(4);
		pagedListHolder10.setPage(0);
		pagedListHolder10.setNewPageSet(false);
		pagedListHolder10.setMaxLinkedPages(10);
		cart0.setItemList(pagedListHolder10);
		
	}
}
